from runAIML import runAIML

inpt = '你好'
test = runAIML(inpt)
if test == '':
    print('QQ')
else:
    print('QQQ')
print(test)
